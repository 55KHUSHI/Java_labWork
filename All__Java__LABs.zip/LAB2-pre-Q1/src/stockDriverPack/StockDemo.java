package stockDriverPack;

import stock.Stock;

public class StockDemo {

	public static void main(String[] args) 
	{
		
		Stock st = new Stock();
		
		double currPrice = 370;
		double prevClosingPrice = 325;
		st.setName("S_Name");
		st.setSymbol("S_Symbol");
		st.setPreviousClosingPrice(currPrice);
		st.setCurrentPrice(prevClosingPrice);
		
		System.out.println("Symbol of the Stock : " + st.getSymbol());
		System.out.println("Name of the Stock : " + st.getName());
		System.out.println("Change in percentage of stock's current price from the previous closing price : " 
		+ st.getChangePercentage(currPrice, prevClosingPrice) + "%");
		

	}

}

