/*
import java.util.Scanner;
 

public class MatrixOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read rows and columns from command line arguments
        int rows = Integer.parseInt(args[0]);
        int cols = Integer.parseInt(args[1]);

        if (rows != cols) {
            System.out.println("Matrix must be square for diagonal operations.");
            return;
        }

        // Initialize the 2D array
        int[][] matrix = new int[rows][cols];

        // Read elements of the matrix from the console
        System.out.println("Enter elements row by row:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }

        // Perform operations
        System.out.println("\nMatrix:");
        printMatrix(matrix);

        System.out.println("\nSum of all elements: " + sumMatrix(matrix));
        System.out.println("\nPrincipal Diagonal Elements:");
        printPrincipalDiagonal(matrix);
        System.out.println("Sum of Principal Diagonal: " + sumPrincipalDiagonal(matrix));
    }

    // Method to print the matrix
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + "\t");
            }
            System.out.println();
        }
    }

    // Method to calculate the sum of all elements
    public static int sumMatrix(int[][] matrix) {
        int sum = 0;
        for (int[] row : matrix) {
            for (int element : row) {
                sum += element;
            }
        }
        return sum;
    }

    // Method to print the principal diagonal
    public static void printPrincipalDiagonal(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            System.out.print(matrix[i][i] + "\t");
        }
        System.out.println();
    }

    // Method to calculate the sum of the principal diagonal
    public static int sumPrincipalDiagonal(int[][] matrix) {
        int sum = 0;
        for (int i = 0; i < matrix.length; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }
}

*/