package reverseWords;

import java.util.Scanner;

public class ReverseWords {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input: Paragraph
        System.out.print("Enter a paragraph: ");
        String paragraph = sc.nextLine();

        // Step 1: Split the paragraph into words
        String[] words = paragraph.split("\\s+");  // Split by spaces

        // Step 2: Reverse each word
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            String reversedWord = reverseWord(word);
            result.append(reversedWord).append(" ");  // Append each reversed word followed by a space
        }

        // Step 3: Output the final result (trim to remove last unnecessary space)
        System.out.println("Reversed words in paragraph: " + result.toString().trim());

        sc.close();
    }

    // Helper method to reverse a single word
    public static String reverseWord(String word) {
        StringBuilder sb = new StringBuilder(word);
        return sb.reverse().toString();  // Reverse the word and return
    }
}
