package shapeHierarchy;

//General class
abstract class Shape {
 private String name;

 public Shape(String name) {
     this.name = name;
 }

 public String getName() {
     return name;
 }

 public abstract void displayDetails();
}

//Two-dimensional shape class
abstract class TwoDShape extends Shape {
 public TwoDShape(String name) {
     super(name);
 }

 public abstract double getArea();
}

//Three-dimensional shape class
abstract class ThreeDShape extends Shape {
 public ThreeDShape(String name) {
     super(name);
 }

 public abstract double getVolume();
}

//Rectangle class
class Rectangle extends TwoDShape {
 private double length;
 private double width;

 public Rectangle(double length, double width) {
     super("Rectangle");
     this.length = length;
     this.width = width;
 }

 @Override
 public double getArea() {
     return length * width;
 }

 @Override
 public void displayDetails() {
     System.out.println("Shape: " + getName());
     System.out.println("Length: " + length + ", Width: " + width);
     System.out.println("Area: " + getArea());
 }
}

//Circle class
class Circle extends TwoDShape {
 private double radius;

 public Circle(double radius) {
     super("Circle");
     this.radius = radius;
 }

 @Override
 public double getArea() {
     return Math.PI * radius * radius;
 }

 @Override
 public void displayDetails() {
     System.out.println("Shape: " + getName());
     System.out.println("Radius: " + radius);
     System.out.println("Area: " + getArea());
 }
}

//Cuboid class
class Cuboid extends ThreeDShape {
 private double length;
 private double width;
 private double height;

 public Cuboid(double length, double width, double height) {
     super("Cuboid");
     this.length = length;
     this.width = width;
     this.height = height;
 }

 @Override
 public double getVolume() {
     return length * width * height;
 }

 @Override
 public void displayDetails() {
     System.out.println("Shape: " + getName());
     System.out.println("Length: " + length + ", Width: " + width + ", Height: " + height);
     System.out.println("Volume: " + getVolume());
 }
}

//Sphere class
class Sphere extends ThreeDShape {
 private double radius;

 public Sphere(double radius) {
     super("Sphere");
     this.radius = radius;
 }

 @Override
 public double getVolume() {
     return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
 }

 @Override
 public void displayDetails() {
     System.out.println("Shape: " + getName());
     System.out.println("Radius: " + radius);
     System.out.println("Volume: " + getVolume());
 }
}

//Main class to test the hierarchy
public class ShapeHierarchy {
 public static void main(String[] args) {
     // Test Rectangle
     Rectangle rectangle = new Rectangle(10, 5);
     rectangle.displayDetails();

     System.out.println();

     // Test Circle
     Circle circle = new Circle(7);
     circle.displayDetails();

     System.out.println();

     // Test Cuboid
     Cuboid cuboid = new Cuboid(4, 3, 2);
     cuboid.displayDetails();

     System.out.println();

     // Test Sphere
     Sphere sphere = new Sphere(6);
     sphere.displayDetails();
 }
}




