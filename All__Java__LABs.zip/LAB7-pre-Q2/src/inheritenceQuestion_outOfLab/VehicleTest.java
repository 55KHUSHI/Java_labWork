package inheritenceQuestion_outOfLab;

//Abstract class Vehicle
abstract class Vehicle {
 // Abstract method
 public abstract void startEngine();

 // Non-abstract method
 public void stopEngine() {
     System.out.println("Engine stopped.");
 }
}

//Car class extending Vehicle
class Car extends Vehicle {
 @Override
 public void startEngine() {
     System.out.println("Car engine started.");
 }
}

//Bike class extending Vehicle
class Bike extends Vehicle {
 @Override
 public void startEngine() {
     System.out.println("Bike engine started.");
 }
}

//Main class to test the implementation
public class VehicleTest {
 public static void main(String[] args) {
     // Create a Car object
     Vehicle car = new Car();
     car.startEngine();
     car.stopEngine();

     // Create a Bike object
     Vehicle bike = new Bike();
     bike.startEngine();
     bike.stopEngine();
 }
}

