package myPackage;

import java.util.Scanner;
import java.lang.Math;


public class QuadraticEquation 
{
	double a;
	double b;
	double c;	
	
	
	
	public double getA() 
	{
		return a;
	}


	public double getB() 
	{
		return b;
	}


	public double getC() 
	{
		return c;
	}

	
	public double getDiscriminant()
	{
		return Math.pow(b, 2) - 4*a*c;
	}
	
	
	public double getRoot1()
	{
		return (-b + Math.sqrt(getDiscriminant()))/(2*a);
	}
	

	public double getRoot2()
	{
		return (-b - Math.sqrt(getDiscriminant()))/(2*a);
	}
	
	
	QuadraticEquation(double a, double b, double c)
	{
		this.a = a;
		this.b = b;
		this.c = c;
	}

	
	
	public static void main(String[] args) 
	{
		double a, b, c;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the coefficients of x square and x and the constant term");
		a = sc.nextDouble();
		b = sc.nextDouble();
		c = sc.nextDouble();
		QuadraticEquation eq = new QuadraticEquation(a, b, c);
		System.out.println("The roots for the equation - '"
				+ eq.getA() + "x2 + " + eq.getB() + "x + " + eq.getC() 
				+ "' are " + eq.getRoot1() + " and " + eq.getRoot2());
		
		sc.close();
		
		
	}

}
