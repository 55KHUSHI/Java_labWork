package stringOperations;

import java.util.Scanner;

public class StringOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nString Operations Menu:");
            System.out.println("1. charAt()");
            System.out.println("2. length()");
            System.out.println("3. indexOf() - all overloaded methods");
            System.out.println("4. lastIndexOf() - all overloaded methods");
            System.out.println("5. substring() - all overloaded methods");
            System.out.println("6. valueOf() - all overloaded methods");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();  // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter a string: ");
                    String str1 = sc.nextLine();
                    System.out.print("Enter index: ");
                    int index = sc.nextInt();
                    System.out.println("charAt(" + index + "): " + str1.charAt(index));
                    break;

                case 2:
                    System.out.print("Enter a string: ");
                    String str2 = sc.nextLine();
                    System.out.println("length(): " + str2.length());
                    break;

                case 3:
                    System.out.print("Enter a string: ");
                    String str3 = sc.nextLine();
                    System.out.print("Enter character to find index: ");
                    char ch = sc.next().charAt(0);
                    System.out.println("indexOf('"+ ch +"'): " + str3.indexOf(ch));
                    System.out.println("indexOf('"+ ch +"', 2): " + str3.indexOf(ch, 2));
                    break;

                case 4:
                    System.out.print("Enter a string: ");
                    String str4 = sc.nextLine();
                    System.out.print("Enter character to find last index: ");
                    char lastChar = sc.next().charAt(0);
                    System.out.println("lastIndexOf('"+ lastChar +"'): " + str4.lastIndexOf(lastChar));
                    System.out.println("lastIndexOf('"+ lastChar +"', 5): " + str4.lastIndexOf(lastChar, 5));
                    break;

                case 5:
                    System.out.print("Enter a string: ");
                    String str5 = sc.nextLine();
                    System.out.println("substring(2): " + str5.substring(2));
                    System.out.println("substring(2, 5): " + str5.substring(2, 5));
                    break;

                case 6:
                    System.out.println("valueOf(123): " + String.valueOf(123));
                    System.out.println("valueOf(true): " + String.valueOf(true));
                    break;

                case 7:
                    exit = true;
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}