package stringBufferOperations;

import java.util.Scanner;

public class StringBufferOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nStringBuffer Operations Menu:");
            System.out.println("1. charAt()");
            System.out.println("2. append()");
            System.out.println("3. capacity()");
            System.out.println("4. length()");
            System.out.println("5. delete()");
            System.out.println("6. deleteCharAt()");
            System.out.println("7. insert()");
            System.out.println("8. reverse()");
            System.out.println("9. replace()");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();  // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter a string: ");
                    StringBuffer sb1 = new StringBuffer(sc.nextLine());
                    System.out.print("Enter index: ");
                    int index = sc.nextInt();
                    System.out.println("charAt(" + index + "): " + sb1.charAt(index));
                    break;

                case 2:
                    System.out.print("Enter a string: ");
                    StringBuffer sb2 = new StringBuffer(sc.nextLine());
                    sb2.append(" appended text.");
                    System.out.println("append(): " + sb2);
                    break;

                case 3:
                    System.out.print("Enter a string: ");
                    StringBuffer sb3 = new StringBuffer(sc.nextLine());
                    System.out.println("capacity(): " + sb3.capacity());
                    break;

                case 4:
                    System.out.print("Enter a string: ");
                    StringBuffer sb4 = new StringBuffer(sc.nextLine());
                    System.out.println("length(): " + sb4.length());
                    break;

                case 5:
                    System.out.print("Enter a string: ");
                    StringBuffer sb5 = new StringBuffer(sc.nextLine());
                    sb5.delete(0, 3);
                    System.out.println("delete(): " + sb5);
                    break;

                case 6:
                    System.out.print("Enter a string: ");
                    StringBuffer sb6 = new StringBuffer(sc.nextLine());
                    sb6.deleteCharAt(0);
                    System.out.println("deleteCharAt(): " + sb6);
                    break;

                case 7:
                    System.out.print("Enter a string: ");
                    StringBuffer sb7 = new StringBuffer(sc.nextLine());
                    sb7.insert(5, " inserted ");
                    System.out.println("insert(): " + sb7);
                    break;

                case 8:
                    System.out.print("Enter a string: ");
                    StringBuffer sb8 = new StringBuffer(sc.nextLine());
                    sb8.reverse();
                    System.out.println("reverse(): " + sb8);
                    break;

                case 9:
                    System.out.print("Enter a string: ");
                    StringBuffer sb9 = new StringBuffer(sc.nextLine());
                    sb9.replace(0, 4, "New");
                    System.out.println("replace(): " + sb9);
                    break;

                case 10:
                    exit = true;
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}

