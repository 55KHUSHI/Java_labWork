package shapeTest;

//Shape interface
interface Shape {
 double area();
 double perimeter();
}

//Circle class implementing Shape interface
class Circle implements Shape {
 private double radius;

 // Constructor
 public Circle(double radius) {
     this.radius = radius;
 }

 // Calculate area
 @Override
 public double area() {
     return Math.PI * radius * radius;
 }

 // Calculate perimeter
 @Override
 public double perimeter() {
     return 2 * Math.PI * radius;
 }
}

//Rectangle class implementing Shape interface
class Rectangle implements Shape {
 private double length;
 private double width;

 // Constructor
 public Rectangle(double length, double width) {
     this.length = length;
     this.width = width;
 }

 // Calculate area
 @Override
 public double area() {
     return length * width;
 }

 // Calculate perimeter
 @Override
 public double perimeter() {
     return 2 * (length + width);
 }
}

//Main class to test the implementation
public class ShapeTest {
 public static void main(String[] args) {
     // Create a Circle object
     Shape circle = new Circle(5);
     System.out.println("Circle Area: " + circle.area());
     System.out.println("Circle Perimeter: " + circle.perimeter());

     // Create a Rectangle object
     Shape rectangle = new Rectangle(4, 6);
     System.out.println("Rectangle Area: " + rectangle.area());
     System.out.println("Rectangle Perimeter: " + rectangle.perimeter());
 }
}

