package LinearSearchTimeEstimation;
import java.util.Random;

public class LinearSearchTiming {
    public static void main(String[] args) {
        int[] array = new int[100000];
        Random random = new Random();

        // Generate random integers for the array
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(1000000); // Random numbers in range [0, 1,000,000)
        }

        int key = array[0]; // Best case: key is the first element
        System.out.println("Best Case:");
        measureExecutionTime(array, key);

        key = array[array.length / 2]; // Average case: key in the middle
        System.out.println("Average Case:");
        measureExecutionTime(array, key);

        key = -1; // Worst case: key not present
        System.out.println("Worst Case:");
        measureExecutionTime(array, key);
    }

    public static void measureExecutionTime(int[] array, int key) {
        long startTime = System.currentTimeMillis();

        // Perform linear search
        boolean found = false;
        for (int num : array) {
            if (num == key) {
                found = true;
                break;
            }
        }

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        System.out.println("Key found: " + found);
        System.out.println("Execution Time: " + executionTime + " ms");
    }
}
