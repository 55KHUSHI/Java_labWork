/*import java.util.Arrays;
import java.util.Scanner;

public class Demo {
    
    // Linear Search
    public static int linearSearch(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                return i;
            }
        }
        return -1;
    }

    // Binary Search
    public static int binarySearch(int[] arr, int key) {
        int left = 0, right = arr.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    // Bubble Sort
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j+1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        // Check if command line arguments are passed
        if (args.length == 0) {
            System.out.println("Please provide a set of integers as command line arguments.");
            return;
        }

        // Parse the command line arguments to an integer array
        int[] arr = new int[args.length];
        for (int i = 0; i < args.length; i++) {
            arr[i] = Integer.parseInt(args[i]);
        }

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Linear Search");
            System.out.println("2. Binary Search");
            System.out.println("3. Bubble Sort");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1: // Linear Search
                    System.out.print("Enter key to search: ");
                    int linearKey = scanner.nextInt();
                    int linearResult = linearSearch(arr, linearKey);
                    if (linearResult != -1) {
                        System.out.println("Key found at index: " + linearResult);
                    } else {
                        System.out.println("Key not found.");
                    }
                    break;

                case 2: // Binary Search
                    bubbleSort(arr); // Ensure the array is sorted before binary search
                    System.out.println("Array sorted for binary search: " + Arrays.toString(arr));
                    System.out.print("Enter key to search: ");
                    int binaryKey = scanner.nextInt();
                    int binaryResult = binarySearch(arr, binaryKey);
                    if (binaryResult != -1) {
                        System.out.println("Key found at index: " + binaryResult);
                    } else {
                        System.out.println("Key not found.");
                    }
                    break;

                case 3: // Bubble Sort
                    bubbleSort(arr);
                    System.out.println("Array after bubble sort: " + Arrays.toString(arr));
                    break;

                case 4: // Exit
                    System.out.println("Exiting the program.");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
*/